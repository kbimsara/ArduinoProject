# Communicate Between Two Arduinos Wirelessly using NRF24L01

## RF24 library by TMRH20 is a dependency for this project
https://tmrh20.github.io/RF24/





### Click below for a demo
https://youtu.be/LlNxvspTLZA
