-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2024 at 06:42 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dunalpj`
--

-- --------------------------------------------------------

--
-- Table structure for table `board`
--

CREATE TABLE `board` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `board`
--

INSERT INTO `board` (`id`, `status`, `time`) VALUES
(1, '0', '2024-08-01 19:01:23');

-- --------------------------------------------------------

--
-- Table structure for table `feeding_times`
--

CREATE TABLE `feeding_times` (
  `id` int(11) NOT NULL,
  `pump_id` int(11) NOT NULL,
  `feeding_time_timestamp` datetime DEFAULT current_timestamp(),
  `feeding_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feeding_times`
--

INSERT INTO `feeding_times` (`id`, `pump_id`, `feeding_time_timestamp`, `feeding_time`) VALUES
(11, 1, '2024-08-07 22:35:02', '22:34:00'),
(12, 1, '2024-08-07 22:35:02', '22:35:00'),
(13, 1, '2024-08-07 22:35:02', '22:37:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'testUser', '$2y$10$qsDAKuT5JNk3WZ72G825z.ZxqyW4QH1aTZhDn6onLV9.SjzM0cORu', '2024-08-07 16:33:24');

-- --------------------------------------------------------

--
-- Table structure for table `water_pump`
--

CREATE TABLE `water_pump` (
  `id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `top_level` int(11) NOT NULL,
  `bottom_level` int(11) NOT NULL,
  `feeding_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `water_pump`
--

INSERT INTO `water_pump` (`id`, `status`, `top_level`, `bottom_level`, `feeding_time`) VALUES
(1, 0, 10, 5, '00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `board`
--
ALTER TABLE `board`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feeding_times`
--
ALTER TABLE `feeding_times`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pump_id` (`pump_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `water_pump`
--
ALTER TABLE `water_pump`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `board`
--
ALTER TABLE `board`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feeding_times`
--
ALTER TABLE `feeding_times`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `water_pump`
--
ALTER TABLE `water_pump`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feeding_times`
--
ALTER TABLE `feeding_times`
  ADD CONSTRAINT `feeding_times_ibfk_1` FOREIGN KEY (`pump_id`) REFERENCES `water_pump` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
