<?php
require_once './config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Connector->query("DELETE FROM feeding_times WHERE pump_id = 1");
    echo json_encode(['message' => 'Feeding history cleared successfully!']);
}
?>
