<?php
require_once './config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $feeding_times = $_POST['feeding_time'];

    // Insert new feeding times without deleting existing ones
    foreach ($feeding_times as $feeding_time) {
        if (!empty($feeding_time)) {
            $stmt = $Connector->prepare("INSERT INTO feeding_times (pump_id, feeding_time) VALUES (1, ?)");
            $stmt->bind_param("s", $feeding_time);
            $stmt->execute();
            $stmt->close();
        }
    }

    echo json_encode(['message' => 'Feeding times saved successfully!']);
}
?>
