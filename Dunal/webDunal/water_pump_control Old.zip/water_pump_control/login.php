<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PetFeeder</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">

</head>
<body class="flex min-h-screen items-center justify-center relative">
    <div class="absolute top-4 right-4">
        <a href="register.php" class="inline-flex items-center justify-center rounded-md text-white px-4 text-sm font-medium py-2">
            Register here
        </a>
    </div>
    <div class="mx-auto w-full max-w-md space-y-8 rounded-lg p-8 shadow-2xl">
        <div class="text-center">
            <h1 class="text-3xl font-bold tracking-tight">Login to PetFeeder</h1>
            <p class="mt-2 text-gray-400">Manage your pet's feeding schedule.</p>
        </div>
        <form class="space-y-6" action="login.php" method="POST">
            <div>
                <label class="text-sm font-medium" for="username">Username</label>
                <input class="flex h-10 rounded-md bg-gray-400 px-3 py-2 mt-1 w-full" id="username" required type="text" name="username" />
            </div>
            <div>
                <label class="text-sm font-medium" for="password">Password</label>
                <input class="flex h-10 rounded-md bg-gray-400 px-3 py-2 mt-1 w-full" id="password" required type="password" name="password" />
            </div>
            <button class="inline-flex items-center justify-center rounded-md bg-blue-500 text-white h-10 px-4 w-full" type="submit">
                Login
            </button>
        </form>

        <?php
        session_start();
        require_once './config.php'; // Include your database connection file

        if (isset($_POST['username']) && isset($_POST['password'])) {
            $username = $_POST['username'];
            $password = $_POST['password'];

            $stmt = $Connector->prepare("SELECT * FROM users WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    header("Location: index.php"); // Redirect to a protected page
                    exit();
                } else {
                    echo "<p class='text-red-500'>Invalid credentials</p>";
                }
            } else {
                echo "<p class='text-red-500'>User not found</p>";
            }
            $stmt->close();
            $Connector->close();
        }
        ?>
    </div>
</body>
</html>
