<?php
$serverName = "localhost";
$userName = "root";
$password = "";
$databaseName = "dunalpj";

// Connect to the database
$Connector = new mysqli($serverName, $userName, $password, $databaseName);

// Check connection
if ($Connector->connect_error) {
    die("Connection failed: " . $Connector->connect_error);
}
?>
