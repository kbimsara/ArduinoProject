<?php
require_once './config.php';

// Fetch current settings
$result = $Connector->query("SELECT * FROM water_pump WHERE id = 1");
$settings = $result->fetch_assoc();

// Fetch feeding history
function fetchFeedingHistory($Connector) {
    $result = $Connector->query("SELECT feeding_time, feeding_time_timestamp FROM feeding_times WHERE pump_id = 1 ORDER BY feeding_time_timestamp DESC");
    return $result->fetch_all(MYSQLI_ASSOC);
}

$feedingHistory = fetchFeedingHistory($Connector);
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <title>Pet Feeder Dashboard</title>
    <style>
        #feedback-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            transition: opacity 0.5s ease;
        }
    </style>
</head>

<body class="flex flex-col min-h-screen bg-background text-foreground">
    <header class="flex items-center justify-between h-16 px-6 border-muted">
        <h1 class="text-2xl font-bold">Pet Feeder Dashboard</h1>
        <div>
            <button id="refresh-button" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded" onclick="window.location.reload();">Refresh</button>
            <a href="login.php" class="hover:bg-red-700 text-white font-bold py-3 px-4 ml-5 rounded">Logout</a>
        </div>
    </header>

    <div id="feedback-notification" class="hidden bg-green-500 text-white px-4 py-2 rounded shadow-lg">
        <p id="feedback-message"></p>
    </div>

    <main class="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
        <div class="rounded-full bg-card text-card-foreground shadow-lg upper-boxes">
            <div class="flex flex-col space-y-1.5 p-10 ml-20">
                <h3 class="whitespace-nowrap text-2xl font-semibold leading-none tracking-tight">Water Levels</h3>
            </div>
            <form id="water-levels-form">
                <div class="p-6 grid gap-4">
                    <div class="grid grid-cols-2 gap-2">
                        <label class="text-sm font-medium leading-none ml-8" for="top-water-level">Top Water Level</label>
                        <input class="flex h-10 w-full rounded-full border border-input bg-background px-3 py-2 text-sm" id="top-water-level" name="top_level" min="0" max="100" type="number" value="<?php echo htmlspecialchars($settings['top_level']); ?>">
                        <label class="text-sm font-medium leading-none" for="bottom-water-level">Bottom Water Level</label>
                        <input class="flex h-10 w-full rounded-full border border-input bg-background px-3 py-2 text-sm" id="bottom-water-level" name="bottom_level" min="0" max="100" type="number" value="<?php echo htmlspecialchars($settings['bottom_level']); ?>">
                    </div>
                    <div class="flex items-center gap-2">
                        <button type="button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded save-it shadow-lg" id="save-water-levels">Save Water Levels</button>
                    </div>
                </div>
            </form>
            <div class="p-6 ml-20">
                    <h3 class="whitespace-nowrap text-2xl font-semibold leading-none ml-20 tracking-tight">Water Pump</h3>
                    <button type="button" class="border bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-5 ml-20" id="pump-on">Turn On</button>
                    <button type="button" class="border #feedback-notificationbg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded ml-5" id="pump-off">Turn Off</button>
                </div>
            </div>
        </div>

        <div class="rounded-lg bg-card text-card-foreground shadow-lg upper-boxes">
            <div class="flex flex-col space-y-1.5 p-6">
                <h3 class="whitespace-nowrap text-2xl font-semibold leading-none tracking-tight">Feeding Times</h3>
            </div>
            <form id="feeding-times-form">
                <div class="p-6 grid gap-4">
                    <div class="grid grid-cols-2 gap-2" id="feeding-times-container">
                        <input class="flex h-10 w-full rounded-md border-input bg-background px-3 py-2 text-sm" id="feeding-time-1" name="feeding_time[]" type="time">
                    </div>
                    <div class="flex justify-end">
                        <button type="button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded shadow-lg" id="add-feeding-time">Add Another Time</button>
                    </div>
                    <div class="flex justify-end gap-2">
                        <button type="button" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded save-it shadow-lg" id="save-feeding-times">Save Feeding Times</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="rounded-lg bg-card text-card-foreground shadow-sm col-span-1 md:col-span-2 upper-boxes">
            <div class="flex flex-col space-y-1.5 p-6">
                <h3 class="whitespace-nowrap text-2xl font-semibold leading-none tracking-tight">Feeding History</h3>
            </div>
            <div class="p-6">
                <div class="relative w-full overflow-auto">
                    <table class="w-full caption-bottom text-sm">
                        <thead class="[&_tr]:border-b">
                            <tr class="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                                <th class="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Time</th>
                                <th class="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Date</th>
                            </tr>
                        </thead>
                        <tbody class="[&_tr:last-child]:border-0">
                            <?php
                            // Fetch feeding history
                            $feedingHistory = fetchFeedingHistory($Connector);
                            if ($feedingHistory):
                                foreach ($feedingHistory as $feeding): ?>
                                    <tr class="border-gray-300 transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                                        <td class="p-4 align-middle"><?php echo htmlspecialchars($feeding['feeding_time']); ?></td>
                                        <td class="p-4 align-middle"><?php echo htmlspecialchars($feeding['feeding_time_timestamp']); ?></td>
                                    </tr>
                                <?php endforeach;
                            else: ?>
                                <tr>
                                    <td colspan="2" class="p-4 text-center">No feeding history available.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="p-6 flex justify-end">
                <button type="button" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded shadow-lg" id="clear-history">Clear History</button>
            </div>
        </div>
    </main>

    <script>
        // Function to show feedback notifications
        function showFeedback(message) {
            const feedbackNotification = document.getElementById('feedback-notification');
            const feedbackMessage = document.getElementById('feedback-message');
            feedbackMessage.textContent = message;
            feedbackNotification.classList.remove('hidden');
            setTimeout(() => {
                feedbackNotification.classList.add('hidden');
            }, 3000); // Automatically hide after 3 seconds
        }

        // Handle water levels form submission
        document.getElementById('save-water-levels').addEventListener('click', function() {
            const form = document.getElementById('water-levels-form');
            const formData = new FormData(form);
            fetch('update_water_levels.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showFeedback(data.message);
            })
            .catch(error => {
                showFeedback('Error updating water levels.');
            });
        });

        // Handle pump on button
        document.getElementById('pump-on').addEventListener('click', function() {
            fetch('update_pump_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ status: 1 })
            })
            .then(response => response.json())
            .then(data => {
                showFeedback(data.message);
            })
            .catch(error => {
                showFeedback('Error turning pump on.');
            });
        });

        // Handle pump off button
        document.getElementById('pump-off').addEventListener('click', function() {
            fetch('update_pump_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ status: 0 })
            })
            .then(response => response.json())
            .then(data => {
                showFeedback(data.message);
            })
            .catch(error => {
                showFeedback('Error turning pump off.');
            });
        });

        // Handle feeding times form submission
        document.getElementById('save-feeding-times').addEventListener('click', function() {
            const form = document.getElementById('feeding-times-form');
            const formData = new FormData(form);
            fetch('update_feeding_times.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showFeedback(data.message);
            })
            .catch(error => {
                showFeedback('Error saving feeding times.');
            });
        });

        // Handle clear history button
        document.getElementById('clear-history').addEventListener('click', function() {
            if (confirm("Are you sure you want to clear the feeding history?")) {
                fetch('clear_history.php', {
                    method: 'POST'
                })
                .then(response => response.json())
                .then(data => {
                    showFeedback(data.message);
                    window.location.reload(); // Refresh the page to update the history
                })
                .catch(error => {
                    showFeedback('Error clearing feeding history.');
                });
            }
        });

        // JavaScript to add more feeding time input fields
        document.getElementById('add-feeding-time').addEventListener('click', function() {
            const container = document.getElementById('feeding-times-container');
            const input = document.createElement('input');
            input.type = 'time';
            input.name = 'feeding_time[]';
            input.className = 'flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm mb-2';
            container.appendChild(input);
        });
    </script>
</body>

</html>
