<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - PetFeeder</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">

</head>
<body class="flex min-h-screen items-center justify-center relative">
    <div class="absolute top-4 right-4">
        <a href="login.php" class="inline-flex items-center justify-center rounded-md text-white px-4 text-sm font-medium py-2">
            Login here
        </a>
    </div>
    <div class="mx-auto w-full max-w-md space-y-8 rounded-lg p-8 shadow-2xl">
        <div class="text-center">
            <h1 class="text-3xl font-bold tracking-tight">Register for PetFeeder</h1>
            <p class="mt-2 text-gray-400">Create an account to manage your pet's feeding schedule.</p>
        </div>
        <form class="space-y-6" action="register.php" method="POST">
            <div>
                <label class="text-sm font-medium" for="username">Username</label>
                <input class="flex h-10 rounded-md border bg-gray-400 border-gray-300 px-3 py-2 mt-1 w-full" id="username" required type="text" name="username" />
            </div>
            <div>
                <label class="text-sm font-medium" for="password">Password</label>
                <input class="flex h-10 rounded-md border bg-gray-400 border-gray-300 px-3 py-2 mt-1 w-full" id="password" required type="password" name="password" />
            </div>
            <button class="inline-flex items-center justify-center rounded-md bg-blue-500 text-white h-10 px-4 w-full" type="submit">
                Register
            </button>
        </form>

        <?php
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            require_once './config.php'; // Include your database connection file

            $username = $_POST['username'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

            $stmt = $Connector->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $password);

            if ($stmt->execute()) {
                echo "<p class='text-green-500'>Registration successful! You can now <a href='login.php' class='text-blue-500'>login</a>.</p>";
            } else {
                echo "<p class='text-red-500'>Error: " . $stmt->error . "</p>";
            }

            $stmt->close();
            $Connector->close();
        }
        ?>
    </div>
</body>
</html>
