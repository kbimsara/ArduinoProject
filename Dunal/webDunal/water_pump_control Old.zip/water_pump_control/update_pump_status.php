<?php
require_once './config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $status = $data['status'];

    $stmt = $Connector->prepare("UPDATE water_pump SET status = ? WHERE id = 1");
    $stmt->bind_param("i", $status);
    
    if ($stmt->execute()) {
        echo json_encode(['message' => 'Pump status updated successfully!']);
    } else {
        echo json_encode(['message' => 'Error updating pump status: ' . $stmt->error]);
    }
    $stmt->close();
}
?>
