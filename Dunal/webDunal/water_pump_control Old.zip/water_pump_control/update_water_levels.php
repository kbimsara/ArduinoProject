<?php
require_once './config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $top_level = $_POST['top_level'];
    $bottom_level = $_POST['bottom_level'];

    $stmt = $Connector->prepare("UPDATE water_pump SET top_level = ?, bottom_level = ? WHERE id = 1");
    $stmt->bind_param("ii", $top_level, $bottom_level);
    
    if ($stmt->execute()) {
        echo json_encode(['message' => 'Water levels updated successfully!']);
    } else {
        echo json_encode(['message' => 'Error updating water levels: ' . $stmt->error]);
    }
    $stmt->close();
}
?>
